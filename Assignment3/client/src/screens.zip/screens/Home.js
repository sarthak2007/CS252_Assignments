import React, { Component } from 'react';
import {
    ScrollView,
    Text,
    TextInput,
    View,
    Button,
    Alert,
    ActivityIndicator
} from 'react-native';

export default class Home extends Component {

    _login = () => {

        this.props.onLogPress();
           
    }

    _signup = () => {

        this.props.onSignPress();
           
    }

    render() {
        return (
            <ScrollView style={{padding: 20}}>
                
                <View style={{margin:150}} />
                <Button 
                    onPress={this._login}
                    title="Log In"
                />
                <View style={{margin:50}} />
                <Button 
                    onPress={this._signup}
                    title="Sign Up"
                />
          </ScrollView>
        )
    }
}