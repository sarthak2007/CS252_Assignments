import React, { Component } from 'react';
import {
    ScrollView,
    Text,
    View,
    Button
} from 'react-native';
import {AsyncStorage} from 'react-native';

export default class Secured extends Component {

    state = {
        id : this.props.token
    }

    // _retrieveData = async () => {
    //   try {
    //     const value = await AsyncStorage.getItem('username');
    //     if (value !== null) {
    //       // We have data!!
    //       this.setState({username: value});
    //     }
    //   } catch (error) {
    //     // Error retrieving data
    //   }
    // };

    render() {
        return (
            <ScrollView style={{padding: 20}}>
                <Text 
                    style={{fontSize: 27}}>
                    Welcome {this.state.id}
                </Text>
                <View style={{margin:300}} />
                <Button
                            onPress={this.props.onLogoutPress}
                            title="Logout"
                        />
                </ScrollView>
                )
    }
}